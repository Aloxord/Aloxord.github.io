<?php  

sleep(2);

echo json_encode(Array["success"=>"1"]])