document.addEventListener("DOMContentLoaded",function(){
	simulator({
		el: "#app",
	})
},true)